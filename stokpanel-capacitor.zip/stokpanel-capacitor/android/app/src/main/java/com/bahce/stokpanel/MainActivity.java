package com.bahce.stokpanel;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
